<form method="get" id="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<span><input type="text" name="s" id="search-string" value="" placeholder="<?php _e('Search...', 'match')?>"/></span>
</form>
